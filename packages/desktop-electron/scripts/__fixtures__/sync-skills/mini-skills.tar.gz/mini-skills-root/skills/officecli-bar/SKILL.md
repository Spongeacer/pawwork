---
name: officecli-bar
description: fixture bar
---

# Bar
